// Carregar variaveis do arquivo .env
require('dotenv').config();


// Importar bibliotecas
const express = require('express');
const { ObjectId } = require('mongodb');
const cors = require('cors');
const path = require('path');
const { exec } = require('child_process');

// Importar conexoes
const pool = require('./database/postgres');

const {
    conectarMongo,
    getDatabase
} = require('./database/mongo');

const {
    driver,
    conectarNeo4j
} = require('./database/neo4j');

// Criar aplicacao
const app = express();

// Configuracoes
app.use(cors());
app.use(express.json());

app.use(express.static(path.join(__dirname, '..', 'frontend')));

const PORT = process.env.PORT || 3000;

// ========================================
// CRUD DE MANUTENCOES - MONGODB
// ========================================

// 1. CADASTRAR MANUTENCAO (CREATE)
app.post('/manutencoes', async (req, res) => {
    try {
        const {
            equipamentoId,
            tecnico,
            descricao,
            dataManutencao,
            tipo,
            status,
            observacoes
        } = req.body;

        if (
            !equipamentoId ||
            !tecnico ||
            !descricao ||
            !dataManutencao ||
            !tipo ||
            !status
        ) {
            return res.status(400).json({
                mensagem: 'Preencha todos os campos obrigatorios!'
            });
        }

        const db = getDatabase();

        const manutencao = {
            equipamentoId: Number(equipamentoId),
            tecnico,
            descricao,
            dataManutencao,
            tipo,
            status,
            observacoes: observacoes || '',
            criadoEm: new Date()
        };

        const resultado = await db
            .collection('manutencoes')
            .insertOne(manutencao);

        res.status(201).json({
            mensagem: 'Manutencao cadastrada com sucesso!',
            manutencao: {
                _id: resultado.insertedId,
                ...manutencao
            }
        });

    } catch (erro) {
        console.error('Erro ao cadastrar manutencao:', erro);

        res.status(500).json({
            mensagem: 'Erro ao cadastrar manutencao.',
            erro: erro.message
        });
    }
});


// 2. LISTAR TODAS AS MANUTENCOES (READ)
app.get('/manutencoes', async (req, res) => {
    try {
        const db = getDatabase();

        const manutencoes = await db
            .collection('manutencoes')
            .find()
            .sort({ criadoEm: -1 })
            .toArray();

        res.json(manutencoes);

    } catch (erro) {
        console.error('Erro ao consultar manutencoes:', erro);

        res.status(500).json({
            mensagem: 'Erro ao consultar manutencoes.',
            erro: erro.message
        });
    }
});


// 3. CONSULTAR MANUTENCAO POR ID (READ)
app.get('/manutencoes/:id', async (req, res) => {
    try {
        const { id } = req.params;

        if (!ObjectId.isValid(id)) {
            return res.status(400).json({
                mensagem: 'ID invalido!'
            });
        }

        const db = getDatabase();

        const manutencao = await db
            .collection('manutencoes')
            .findOne({ _id: new ObjectId(id) });

        if (!manutencao) {
            return res.status(404).json({
                mensagem: 'Manutencao nao encontrada!'
            });
        }

        res.json(manutencao);

    } catch (erro) {
        res.status(500).json({
            mensagem: 'Erro ao consultar manutencao.',
            erro: erro.message
        });
    }
});


// 4. ATUALIZAR MANUTENCAO (UPDATE)
app.put('/manutencoes/:id', async (req, res) => {
    try {
        const { id } = req.params;

        if (!ObjectId.isValid(id)) {
            return res.status(400).json({
                mensagem: 'ID invalido!'
            });
        }

        const {
            equipamentoId,
            tecnico,
            descricao,
            dataManutencao,
            tipo,
            status,
            observacoes
        } = req.body;

        if (
            !equipamentoId ||
            !tecnico ||
            !descricao ||
            !dataManutencao ||
            !tipo ||
            !status
        ) {
            return res.status(400).json({
                mensagem: 'Preencha todos os campos obrigatorios!'
            });
        }

        const db = getDatabase();

        const resultado = await db
            .collection('manutencoes')
            .updateOne(
                { _id: new ObjectId(id) },
                {
                    $set: {
                        equipamentoId: Number(equipamentoId),
                        tecnico,
                        descricao,
                        dataManutencao,
                        tipo,
                        status,
                        observacoes: observacoes || ''
                    }
                }
            );

        if (resultado.matchedCount === 0) {
            return res.status(404).json({
                mensagem: 'Manutencao nao encontrada!'
            });
        }

        res.json({
            mensagem: 'Manutencao atualizada com sucesso!'
        });

    } catch (erro) {
        console.error('Erro ao atualizar manutencao:', erro);

        res.status(500).json({
            mensagem: 'Erro ao atualizar manutencao.',
            erro: erro.message
        });
    }
});


// 5. EXCLUIR MANUTENCAO (DELETE)
app.delete('/manutencoes/:id', async (req, res) => {
    try {
        const { id } = req.params;

        if (!ObjectId.isValid(id)) {
            return res.status(400).json({
                mensagem: 'ID invalido!'
            });
        }

        const db = getDatabase();

        const resultado = await db
            .collection('manutencoes')
            .deleteOne({
                _id: new ObjectId(id)
            });

        if (resultado.deletedCount === 0) {
            return res.status(404).json({
                mensagem: 'Manutencao nao encontrada!'
            });
        }

        res.json({
            mensagem: 'Manutencao excluida com sucesso!'
        });

    } catch (erro) {
        console.error('Erro ao excluir manutencao:', erro);

        res.status(500).json({
            mensagem: 'Erro ao excluir manutencao.',
            erro: erro.message
        });
    }
});


// ========================================
// CRUD DE EQUIPAMENTOS - POSTGRESQL
// ========================================

// 1. CADASTRAR EQUIPAMENTO (CREATE)
app.post('/equipamentos', async (req, res) => {
    try {
        const {
            nome,
            fabricante,
            modelo,
            numero_serie,
            data_aquisicao,
            status
        } = req.body;

        // Validar campos obrigatorios
        if (!nome || !fabricante || !modelo || !numero_serie) {
            return res.status(400).json({
                mensagem: 'Preencha todos os campos obrigatorios!'
            });
        }

        const resultado = await pool.query(
            `INSERT INTO equipamentos
            (nome, fabricante, modelo, numero_serie, data_aquisicao, status)
            VALUES ($1, $2, $3, $4, $5, $6)
            RETURNING *`,
            [
                nome,
                fabricante,
                modelo,
                numero_serie,
                data_aquisicao || null,
                status || 'Disponível'
            ]
        );

        res.status(201).json({
            mensagem: 'Equipamento cadastrado com sucesso!',
            equipamento: resultado.rows[0]
        });

    } catch (erro) {
        console.error('Erro ao cadastrar:', erro.message);

        if (erro.code === '23505') {
            return res.status(409).json({
                mensagem: 'Este numero de serie ja esta cadastrado!'
            });
        }

        res.status(500).json({
            mensagem: 'Erro ao cadastrar equipamento.',
            erro: erro.message
        });
    }
});


// 2. LISTAR TODOS OS EQUIPAMENTOS (READ)
app.get('/equipamentos', async (req, res) => {
    try {
        const resultado = await pool.query(
            'SELECT * FROM equipamentos ORDER BY id'
        );

        res.json(resultado.rows);

    } catch (erro) {
        console.error('Erro ao consultar:', erro.message);

        res.status(500).json({
            mensagem: 'Erro ao consultar equipamentos.',
            erro: erro.message
        });
    }
});


// 3. CONSULTAR EQUIPAMENTO POR ID (READ)
app.get('/equipamentos/:id', async (req, res) => {
    try {
        const id = Number(req.params.id);

        if (!Number.isInteger(id) || id <= 0) {
            return res.status(400).json({
                mensagem: 'ID invalido!'
            });
        }

        const resultado = await pool.query(
            'SELECT * FROM equipamentos WHERE id = $1',
            [id]
        );

        if (resultado.rows.length === 0) {
            return res.status(404).json({
                mensagem: 'Equipamento nao encontrado!'
            });
        }

        res.json(resultado.rows[0]);

    } catch (erro) {
        res.status(500).json({
            mensagem: 'Erro ao consultar equipamento.',
            erro: erro.message
        });
    }
});


// 4. ATUALIZAR EQUIPAMENTO (UPDATE)
app.put('/equipamentos/:id', async (req, res) => {
    try {
        const id = Number(req.params.id);

        if (!Number.isInteger(id) || id <= 0) {
            return res.status(400).json({
                mensagem: 'ID invalido!'
            });
        }

        const {
            nome,
            fabricante,
            modelo,
            numero_serie,
            data_aquisicao,
            status
        } = req.body;

        if (!nome || !fabricante || !modelo || !numero_serie) {
            return res.status(400).json({
                mensagem: 'Preencha todos os campos obrigatorios!'
            });
        }

        const resultado = await pool.query(
            `UPDATE equipamentos
             SET nome = $1,
                 fabricante = $2,
                 modelo = $3,
                 numero_serie = $4,
                 data_aquisicao = $5,
                 status = $6
             WHERE id = $7
             RETURNING *`,
            [
                nome,
                fabricante,
                modelo,
                numero_serie,
                data_aquisicao || null,
                status || 'Disponível',
                id
            ]
        );

        if (resultado.rows.length === 0) {
            return res.status(404).json({
                mensagem: 'Equipamento nao encontrado!'
            });
        }

        res.json({
            mensagem: 'Equipamento atualizado com sucesso!',
            equipamento: resultado.rows[0]
        });

    } catch (erro) {
        console.error('Erro ao atualizar:', erro.message);

        if (erro.code === '23505') {
            return res.status(409).json({
                mensagem: 'Este numero de serie ja esta cadastrado!'
            });
        }

        res.status(500).json({
            mensagem: 'Erro ao atualizar equipamento.',
            erro: erro.message
        });
    }
});


// 5. EXCLUIR EQUIPAMENTO (DELETE)
app.delete('/equipamentos/:id', async (req, res) => {
    try {
        const id = Number(req.params.id);

        if (!Number.isInteger(id) || id <= 0) {
            return res.status(400).json({
                mensagem: 'ID invalido!'
            });
        }

        const resultado = await pool.query(
            'DELETE FROM equipamentos WHERE id = $1 RETURNING *',
            [id]
        );

        if (resultado.rows.length === 0) {
            return res.status(404).json({
                mensagem: 'Equipamento nao encontrado!'
            });
        }

        res.json({
            mensagem: 'Equipamento excluido com sucesso!',
            equipamento: resultado.rows[0]
        });

    } catch (erro) {
        console.error('Erro ao excluir:', erro.message);

        res.status(500).json({
            mensagem: 'Erro ao excluir equipamento.',
            erro: erro.message
        });
    }
});


// Rota inicial
app.get('/', (req, res) => {
    res.json({
        sistema: 'MedTech',
        mensagem: 'API funcionando!'
    });
});

// Testar PostgreSQL
app.get('/teste-postgres', async (req, res) => {
    try {
        const resultado = await pool.query('SELECT NOW()');

        res.json({
            mensagem: 'Conexao com PostgreSQL realizada com sucesso!',
            horario: resultado.rows[0].now
        });

    } catch (erro) {
        res.status(500).json({
            mensagem: 'Erro ao conectar com PostgreSQL',
            erro: erro.message
        });
    }
});

// Testar MongoDB
app.get('/teste-mongo', async (req, res) => {
    try {
        const db = getDatabase();

        await db.command({ ping: 1 });

        res.json({
            mensagem: 'Conexao com MongoDB realizada com sucesso!',
            banco: process.env.MONGO_DATABASE
        });

    } catch (erro) {
        res.status(500).json({
            mensagem: 'Erro ao conectar com MongoDB',
            erro: erro.message
        });
    }
});

// Testar Neo4j
app.get('/teste-neo4j', async (req, res) => {
    let session;

    try {
        session = driver.session({
            database: process.env.NEO4J_DATABASE
        });

        const resultado = await session.run(
            'RETURN 1 AS teste'
        );

        res.json({
            mensagem: 'Conexao com Neo4j realizada com sucesso!',
            resultado: resultado.records[0].get('teste')
        });

    } catch (erro) {
        res.status(500).json({
            mensagem: 'Erro ao conectar com Neo4j',
            erro: erro.message
        });

    } finally {
        if (session) {
            await session.close();
        }
    }
});

// ========================================
// RELACIONAMENTOS - NEO4J
// ========================================

// 1. RELACIONAR EQUIPAMENTO COM MANUTENCAO
app.post('/relacionamentos', async (req, res) => {
    const session = driver.session({
        database: process.env.NEO4J_DATABASE
    });

    try {
        const { equipamentoId, manutencaoId } = req.body;

        if (!equipamentoId || !manutencaoId) {
            return res.status(400).json({
                mensagem: 'Informe o ID do equipamento e da manutencao!'
            });
        }

        const idEquipamento = Number(equipamentoId);

        if (!Number.isInteger(idEquipamento) || idEquipamento <= 0) {
            return res.status(400).json({
                mensagem: 'ID do equipamento invalido!'
            });
        }

        if (!ObjectId.isValid(manutencaoId)) {
            return res.status(400).json({
                mensagem: 'ID da manutencao invalido!'
            });
        }

        // Verificar se o equipamento existe no PostgreSQL
        const equipamento = await pool.query(
            'SELECT * FROM equipamentos WHERE id = $1',
            [idEquipamento]
        );

        if (equipamento.rows.length === 0) {
            return res.status(404).json({
                mensagem: 'Equipamento nao encontrado no PostgreSQL!'
            });
        }

        // Verificar se a manutencao existe no MongoDB
        const db = getDatabase();

        const manutencao = await db
            .collection('manutencoes')
            .findOne({
                _id: new ObjectId(manutencaoId)
            });

        if (!manutencao) {
            return res.status(404).json({
                mensagem: 'Manutencao nao encontrada no MongoDB!'
            });
        }
        // Verificar se a manutencao pertence ao equipamento informado
        if (Number(manutencao.equipamentoId) !== idEquipamento) {
            return res.status(400).json({
                mensagem: 'A manutencao nao pertence a este equipamento!'
            });
        }

        // Criar os nos e o relacionamento no Neo4j
        const resultado = await session.run(
            `
            MERGE (e:Equipamento {postgresId: $equipamentoId})
            SET e.nome = $nomeEquipamento,
                e.numeroSerie = $numeroSerie

            MERGE (m:Manutencao {mongoId: $manutencaoId})
            SET m.descricao = $descricao,
                m.tecnico = $tecnico,
                m.tipo = $tipo,
                m.status = $status

            MERGE (e)-[r:TEVE_MANUTENCAO]->(m)

            RETURN e, r, m
            `,
            {
                equipamentoId: idEquipamento,
                nomeEquipamento: equipamento.rows[0].nome,
                numeroSerie: equipamento.rows[0].numero_serie,
                manutencaoId: manutencaoId,
                descricao: manutencao.descricao,
                tecnico: manutencao.tecnico,
                tipo: manutencao.tipo,
                status: manutencao.status
            }
        );

        res.status(201).json({
            mensagem: 'Relacionamento criado com sucesso no Neo4j!',
            equipamentoId: idEquipamento,
            manutencaoId: manutencaoId,
            resultado: resultado.records.length
        });

    } catch (erro) {
        console.error('Erro ao criar relacionamento:', erro);

        res.status(500).json({
            mensagem: 'Erro ao criar relacionamento.',
            erro: erro.message
        });

    } finally {
        await session.close();
    }
});


// 2. CONSULTAR RELACIONAMENTOS NO NEO4J
app.get('/relacionamentos', async (req, res) => {
    const session = driver.session({
        database: process.env.NEO4J_DATABASE
    });

    try {
        const resultado = await session.run(`
            MATCH (e:Equipamento)-[r:TEVE_MANUTENCAO]->(m:Manutencao)
            RETURN e, r, m
            ORDER BY e.postgresId
        `);

        const relacionamentos = resultado.records.map(registro => ({
            equipamento: registro.get('e').properties,
            relacionamento: registro.get('r').type,
            manutencao: registro.get('m').properties
        }));

        res.json(relacionamentos);

    } catch (erro) {
        console.error('Erro ao consultar relacionamentos:', erro);

        res.status(500).json({
            mensagem: 'Erro ao consultar relacionamentos.',
            erro: erro.message
        });

    } finally {
        await session.close();
    }
});


// 3. ATUALIZAR RELACIONAMENTO NO NEO4J (UPDATE)

 // ========================================
 // ATUALIZAR RELACIONAMENTO - NEO4J
 // ========================================

app.put('/relacionamentos/:equipamentoId/:manutencaoId', async (req, res) => {

    const session = driver.session({
        database: process.env.NEO4J_DATABASE
    });

    try {

        // IDs antigos, identificados pela URL
        const equipamentoIdAntigo = Number(req.params.equipamentoId);

        const manutencaoIdAntiga = req.params.manutencaoId;

        // Novos IDs, recebidos pelo formulário do frontend
        const equipamentoIdNovo = Number(req.body.equipamentoId);

        const manutencaoIdNova = req.body.manutencaoId;

        // ========================================
        // VALIDAR OS IDS
        // ========================================

        if (
            !Number.isInteger(equipamentoIdAntigo) ||
            equipamentoIdAntigo <= 0 ||
            !ObjectId.isValid(manutencaoIdAntiga) ||
            !Number.isInteger(equipamentoIdNovo) ||
            equipamentoIdNovo <= 0 ||
            !ObjectId.isValid(manutencaoIdNova)
        ) {

            return res.status(400).json({
                mensagem: 'IDs inválidos.'
            });
        }

        // ========================================
        // CONSULTAR EQUIPAMENTO NO POSTGRESQL
        // ========================================

        const resultadoEquipamento = await pool.query(
            'SELECT * FROM equipamentos WHERE id = $1',
            [equipamentoIdNovo]
        );

        if (resultadoEquipamento.rows.length === 0) {

            return res.status(404).json({
                mensagem: 'Novo equipamento não encontrado no PostgreSQL.'
            });
        }

        const equipamento = resultadoEquipamento.rows[0];

        // ========================================
        // CONSULTAR MANUTENCAO NO MONGODB
        // ========================================

        const db = getDatabase();

        const manutencao = await db.collection('manutencoes').findOne({
            _id: new ObjectId(manutencaoIdNova)
        });

        if (!manutencao) {

            return res.status(404).json({
                mensagem: 'Nova manutenção não encontrada no MongoDB.'
            });
        }

        // ========================================
        // VALIDAR SE A MANUTENCAO PERTENCE AO EQUIPAMENTO
        // ========================================

        if (Number(manutencao.equipamentoId) !== equipamentoIdNovo) {

            return res.status(400).json({
                mensagem:
                    'A manutenção selecionada não pertence ao equipamento escolhido.'
            });
        }

        // ========================================
        // ATUALIZAR RELACIONAMENTO NO NEO4J
        // ========================================

        const atualizadoEm = new Date().toISOString();

        const resultado = await session.executeWrite(async tx => {

            // Verifica se o relacionamento antigo existe
            const relacionamentoAntigo = await tx.run(
                `
                MATCH (e:Equipamento {postgresId: $equipamentoIdAntigo})
                      -[r:TEVE_MANUTENCAO]->
                      (m:Manutencao {mongoId: $manutencaoIdAntiga})
                RETURN r
                `,
                {
                    equipamentoIdAntigo,
                    manutencaoIdAntiga
                }
            );

            if (relacionamentoAntigo.records.length === 0) {
                return false;
            }

            // Remove o relacionamento antigo
            await tx.run(
                `
                MATCH (e:Equipamento {postgresId: $equipamentoIdAntigo})
                      -[r:TEVE_MANUTENCAO]->
                      (m:Manutencao {mongoId: $manutencaoIdAntiga})
                DELETE r
                `,
                {
                    equipamentoIdAntigo,
                    manutencaoIdAntiga
                }
            );

            // Cria ou atualiza os nós e o novo relacionamento
            await tx.run(
                `
                MERGE (e:Equipamento {postgresId: $equipamentoIdNovo})
                SET e.nome = $nomeEquipamento,
                    e.numeroSerie = $numeroSerie

                MERGE (m:Manutencao {mongoId: $manutencaoIdNova})
                SET m.descricao = $descricao,
                    m.tecnico = $tecnico,
                    m.tipo = $tipo,
                    m.status = $status

                MERGE (e)-[r:TEVE_MANUTENCAO]->(m)
                SET r.atualizadoEm = $atualizadoEm

                RETURN e, r, m
                `,
                {
                    equipamentoIdNovo,
                    manutencaoIdNova,
                    nomeEquipamento: equipamento.nome,
                    numeroSerie: equipamento.numero_serie,
                    descricao: manutencao.descricao,
                    tecnico: manutencao.tecnico,
                    tipo: manutencao.tipo,
                    status: manutencao.status,
                    atualizadoEm
                }
            );

            return true;
        });

        if (!resultado) {

            return res.status(404).json({
                mensagem: 'Relacionamento antigo não encontrado no Neo4j.'
            });
        }

        res.json({
            mensagem: 'Relacionamento atualizado com sucesso no Neo4j!',
            equipamentoIdAntigo,
            manutencaoIdAntiga,
            equipamentoIdNovo,
            manutencaoIdNova
        });

    } catch (erro) {

        console.error('Erro ao atualizar relacionamento:', erro);

        res.status(500).json({
            mensagem: 'Erro ao atualizar relacionamento no Neo4j.',
            erro: erro.message
        });

    } finally {

        await session.close();

    }

});




// 4. EXCLUIR RELACIONAMENTO NO NEO4J (DELETE)
app.delete('/relacionamentos/:equipamentoId/:manutencaoId', async (req, res) => {
    const session = driver.session({
        database: process.env.NEO4J_DATABASE
    });

    try {
        const idEquipamento = Number(req.params.equipamentoId);
        const manutencaoId = req.params.manutencaoId;

        // Validar ID do equipamento
        if (!Number.isInteger(idEquipamento) || idEquipamento <= 0) {
            return res.status(400).json({
                mensagem: 'ID do equipamento invalido!'
            });
        }

        // Validar ID da manutencao
        if (!ObjectId.isValid(manutencaoId)) {
            return res.status(400).json({
                mensagem: 'ID da manutencao invalido!'
            });
        }

        // Localizar e excluir somente o relacionamento
        const resultado = await session.run(
            `
            MATCH (e:Equipamento {postgresId: $equipamentoId})
                  -[r:TEVE_MANUTENCAO]->
                  (m:Manutencao {mongoId: $manutencaoId})

            DELETE r

            RETURN count(r) AS excluidos
            `,
            {
                equipamentoId: idEquipamento,
                manutencaoId: manutencaoId
            }
        );

        const excluidos = resultado.records[0]
            .get('excluidos').toNumber();

        if (excluidos === 0) {
            return res.status(404).json({
                mensagem: 'Relacionamento nao encontrado no Neo4j!'
            });
        }

        res.json({
            mensagem: 'Relacionamento excluido com sucesso no Neo4j!',
            equipamentoId: idEquipamento,
            manutencaoId: manutencaoId
        });

    } catch (erro) {
        console.error('Erro ao excluir relacionamento:', erro);

        res.status(500).json({
            mensagem: 'Erro ao excluir relacionamento.',
            erro: erro.message
        });

    } finally {
        await session.close();
    }
});



// Iniciar servidor
async function iniciarServidor() {
    try {
        // Conectar MongoDB
        await conectarMongo();

        console.log('MongoDB conectado com sucesso!');

        // Conectar Neo4j
        await conectarNeo4j();

        console.log('Neo4j conectado com sucesso!');

        // Iniciar Express
        app.listen(PORT, () => {
        console.log('================================');
        console.log('MEDTECH INICIADO COM SUCESSO!');
        console.log(`Servidor: http://localhost:${PORT}`);
        console.log('================================');

        // Abrir automaticamente o navegador
            exec(`start "" "http://localhost:${PORT}/"`);
        });




    } catch (erro) {
        console.error(
            'Erro ao iniciar o sistema:',
            erro.message
        );
    }
}

iniciarServidor();