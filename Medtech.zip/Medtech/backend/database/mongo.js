const { MongoClient } = require('mongodb');

const client = new MongoClient(process.env.MONGO_URL);

let database;

async function conectarMongo() {
    await client.connect();

    database = client.db(process.env.MONGO_DATABASE);

    console.log('Conectado ao MongoDB!');
}

function getDatabase() {
    if (!database) {
        throw new Error('MongoDB ainda não foi conectado!');
    }

    return database;
}

module.exports = {
    conectarMongo,
    getDatabase
};