const neo4j = require('neo4j-driver');

const driver = neo4j.driver(
    process.env.NEO4J_URI,
    neo4j.auth.basic(
        process.env.NEO4J_USERNAME,
        process.env.NEO4J_PASSWORD
    )
);

async function conectarNeo4j() {
    await driver.verifyConnectivity();

    console.log('Conectado ao Neo4j!');
}

module.exports = {
    driver,
    conectarNeo4j
};