
// ========================================
// CONFIGURACAO DA API
// ========================================

const API = 'http://localhost:3000';


// ========================================
// ELEMENTOS DA PAGINA
// ========================================

const formEquipamento = document.getElementById('formEquipamento');
const formManutencao = document.getElementById('formManutencao');
const formRelacionamento = document.getElementById('formRelacionamento');

const listaEquipamentos = document.getElementById('listaEquipamentos');
const listaManutencoes = document.getElementById('listaManutencoes');
const listaRelacionamentos = document.getElementById('listaRelacionamentos');

const equipamentoManutencao =
    document.getElementById('equipamentoManutencao');

const equipamentoRelacionamento =
    document.getElementById('equipamentoRelacionamento');

const manutencaoRelacionamento =
    document.getElementById('manutencaoRelacionamento');


// ========================================
// FUNCAO PARA MOSTRAR MENSAGENS
// ========================================

function mostrarMensagem(elemento, mensagem, tipo) {

    const div = document.createElement('div');

    div.className = `mensagem ${tipo}`;
    div.textContent = mensagem;

    elemento.prepend(div);

    setTimeout(() => {
        div.remove();
    }, 4000);
}


// ========================================
// LISTAR EQUIPAMENTOS - POSTGRESQL
// ========================================

async function carregarEquipamentos() {

    try {

        const resposta = await fetch(`${API}/equipamentos`);

        if (!resposta.ok) {
            throw new Error('Erro ao consultar equipamentos.');
        }

        const equipamentos = await resposta.json();

        listaEquipamentos.innerHTML = '';

        equipamentoManutencao.innerHTML =
            '<option value="">Selecione um equipamento</option>';

        equipamentoRelacionamento.innerHTML =
            '<option value="">Selecione um equipamento</option>';

        if (equipamentos.length === 0) {

            listaEquipamentos.textContent =
                'Nenhum equipamento cadastrado.';

            return;
        }

        const tabela = document.createElement('table');

        tabela.innerHTML = `
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Fabricante</th>
                    <th>Modelo</th>
                    <th>Número de série</th>
                    <th>Status</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody></tbody>
        `;

        const tbody = tabela.querySelector('tbody');

        equipamentos.forEach(e => {

            const linha = document.createElement('tr');

            const valores = [
                e.id,
                e.nome,
                e.fabricante,
                e.modelo,
                e.numero_serie,
                e.status
            ];

            valores.forEach(valor => {
                const td = document.createElement('td');
                td.textContent = valor ?? '';
                linha.appendChild(td);
            });

            const acoes = document.createElement('td');

            const botaoEditar = document.createElement('button');
            botaoEditar.textContent = 'Editar';
            botaoEditar.className = 'editar';
            botaoEditar.onclick = () => editarEquipamento(e);

            const botaoExcluir = document.createElement('button');
            botaoExcluir.textContent = 'Excluir';
            botaoExcluir.className = 'excluir';
            botaoExcluir.onclick = () => excluirEquipamento(e.id);

            acoes.append(botaoEditar, botaoExcluir);
            linha.appendChild(acoes);

            tbody.appendChild(linha);

            // Preenche o campo de equipamento do cadastro de manutenção
            const opcaoManutencao = document.createElement('option');
            opcaoManutencao.value = e.id;
            opcaoManutencao.textContent =
                `${e.nome} - ${e.numero_serie}`;

            equipamentoManutencao.appendChild(opcaoManutencao);

            // Preenche o campo de equipamento do relacionamento Neo4j
            const opcaoRelacionamento = document.createElement('option');
            opcaoRelacionamento.value = e.id;
            opcaoRelacionamento.textContent =
                `${e.nome} - ${e.numero_serie} (ID: ${e.id})`;

            equipamentoRelacionamento.appendChild(opcaoRelacionamento);

        });

        listaEquipamentos.appendChild(tabela);

    } catch (erro) {

        console.error(erro);

        listaEquipamentos.textContent =
            'Não foi possível carregar os equipamentos.';
    }
}


// ========================================
// CADASTRAR OU ATUALIZAR EQUIPAMENTO
// ========================================

formEquipamento.addEventListener('submit', async (evento) => {

    evento.preventDefault();

    const id = document.getElementById('equipamentoId').value;

    const equipamento = {

        nome: document.getElementById('nome').value,

        fabricante: document.getElementById('fabricante').value,

        modelo: document.getElementById('modelo').value,

        numero_serie: document.getElementById('numeroSerie').value,

        data_aquisicao:
            document.getElementById('dataAquisicao').value,

        status:
            document.getElementById('statusEquipamento').value
    };

    try {

        const resposta = await fetch(
            id ? `${API}/equipamentos/${id}` : `${API}/equipamentos`,
            {
                method: id ? 'PUT' : 'POST',

                headers: {
                    'Content-Type': 'application/json'
                },

                body: JSON.stringify(equipamento)
            }
        );

        const dados = await resposta.json();

        if (!resposta.ok) {
            throw new Error(dados.mensagem || 'Erro ao salvar equipamento.');
        }

        alert(dados.mensagem);

        formEquipamento.reset();

        document.getElementById('equipamentoId').value = '';

        await carregarEquipamentos();

    } catch (erro) {

        alert(erro.message);
    }
});


// ========================================
// EDITAR EQUIPAMENTO
// ========================================

function editarEquipamento(e) {

    document.getElementById('equipamentoId').value = e.id;

    document.getElementById('nome').value = e.nome;

    document.getElementById('fabricante').value = e.fabricante;

    document.getElementById('modelo').value = e.modelo;

    document.getElementById('numeroSerie').value = e.numero_serie;

    document.getElementById('dataAquisicao').value =
        e.data_aquisicao ? e.data_aquisicao.substring(0, 10) : '';

    document.getElementById('statusEquipamento').value = e.status;

    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
}


// ========================================
// CANCELAR EDICAO
// ========================================

document.getElementById('cancelarEdicao').addEventListener('click', () => {

    formEquipamento.reset();

    document.getElementById('equipamentoId').value = '';

});


// ========================================
// EXCLUIR EQUIPAMENTO
// ========================================

async function excluirEquipamento(id) {

    if (!confirm('Deseja realmente excluir este equipamento?')) {
        return;
    }

    try {

        const resposta = await fetch(`${API}/equipamentos/${id}`, {
            method: 'DELETE'
        });

        const dados = await resposta.json();

        if (!resposta.ok) {
            throw new Error(dados.mensagem || 'Erro ao excluir equipamento.');
        }

        alert(dados.mensagem);

        await carregarEquipamentos();

    } catch (erro) {

        alert(erro.message);
    }
}


// ========================================
// CADASTRAR MANUTENCAO - MONGODB
// ========================================

formManutencao.addEventListener('submit', async (evento) => {

    evento.preventDefault();

    const manutencao = {

        equipamentoId:
            Number(equipamentoManutencao.value),

        tecnico:
            document.getElementById('tecnico').value,

        descricao:
            document.getElementById('descricao').value,

        dataManutencao:
            document.getElementById('dataManutencao').value,

        tipo:
            document.getElementById('tipo').value,

        status:
            document.getElementById('statusManutencao').value,

        observacoes:
            document.getElementById('observacoes').value
    };

    try {

        const resposta = await fetch(`${API}/manutencoes`, {

            method: 'POST',

            headers: {
                'Content-Type': 'application/json'
            },

            body: JSON.stringify(manutencao)
        });

        const dados = await resposta.json();

        if (!resposta.ok) {
            throw new Error(dados.mensagem || 'Erro ao cadastrar manutenção.');
        }

        alert(dados.mensagem);

        formManutencao.reset();

        await carregarManutencoes();

    } catch (erro) {

        alert(erro.message);
    }
});


// ========================================
// LISTAR MANUTENCOES - MONGODB
// ========================================

async function carregarManutencoes() {

    try {

        const resposta = await fetch(`${API}/manutencoes`);

        if (!resposta.ok) {
            throw new Error('Erro ao consultar manutenções.');
        }

        const manutencoes = await resposta.json();

        listaManutencoes.innerHTML = '';

        manutencaoRelacionamento.innerHTML =
            '<option value="">Selecione uma manutenção</option>';

        if (manutencoes.length === 0) {

            listaManutencoes.textContent =
                'Nenhuma manutenção cadastrada.';

            return;
        }

        const tabela = document.createElement('table');

        tabela.innerHTML = `
            <thead>
                <tr>
                    <th>Equipamento ID</th>
                    <th>Técnico</th>
                    <th>Descrição</th>
                    <th>Data</th>
                    <th>Tipo</th>
                    <th>Status</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody></tbody>
        `;

        const tbody = tabela.querySelector('tbody');

        manutencoes.forEach(m => {

            const linha = document.createElement('tr');

            const valores = [
                m.equipamentoId,
                m.tecnico,
                m.descricao,
                m.dataManutencao,
                m.tipo,
                m.status
            ];

            valores.forEach(valor => {

                const td = document.createElement('td');

                td.textContent = valor ?? '';

                linha.appendChild(td);
            });

            const acoes = document.createElement('td');

            const botaoExcluir = document.createElement('button');

            botaoExcluir.textContent = 'Excluir';

            botaoExcluir.className = 'excluir';

            botaoExcluir.onclick = () => excluirManutencao(m._id);

            const botaoEditar = document.createElement('button');

            botaoEditar.textContent = 'Editar';

            botaoEditar.className = 'editar';

            botaoEditar.onclick = () => editarManutencao(m);

            acoes.append(botaoEditar, botaoExcluir);

            linha.appendChild(acoes);

            tbody.appendChild(linha);

            // Inclui a manutenção na seleção do relacionamento
            const opcao = document.createElement('option');

            opcao.value = m._id;

            opcao.textContent =
                `ID equipamento: ${m.equipamentoId} - ${m.tecnico} - ${m.tipo} - ${m.descricao}`;

            manutencaoRelacionamento.appendChild(opcao);

        });

        listaManutencoes.appendChild(tabela);

    } catch (erro) {

        console.error(erro);

        listaManutencoes.textContent =
            'Não foi possível carregar as manutenções.';
    }
}


// ========================================
// EDITAR MANUTENCAO
// ========================================

async function editarManutencao(m) {

    const tecnico = prompt('Técnico responsável:', m.tecnico);

    if (tecnico === null) return;

    const descricao = prompt('Descrição:', m.descricao);

    if (descricao === null) return;

    const status = prompt('Status:', m.status);

    if (status === null) return;

    const manutencao = {

        equipamentoId: m.equipamentoId,

        tecnico: tecnico,

        descricao: descricao,

        dataManutencao: m.dataManutencao,

        tipo: m.tipo,

        status: status,

        observacoes: m.observacoes || ''
    };

    try {

        const resposta = await fetch(
            `${API}/manutencoes/${m._id}`,
            {
                method: 'PUT',

                headers: {
                    'Content-Type': 'application/json'
                },

                body: JSON.stringify(manutencao)
            }
        );

        const dados = await resposta.json();

        if (!resposta.ok) {
            throw new Error(dados.mensagem || 'Erro ao atualizar manutenção.');
        }

        alert(dados.mensagem);

        await carregarManutencoes();

    } catch (erro) {

        alert(erro.message);
    }
}


// ========================================
// EXCLUIR MANUTENCAO
// ========================================

async function excluirManutencao(id) {

    if (!confirm('Deseja realmente excluir esta manutenção?')) {
        return;
    }

    try {

        const resposta = await fetch(`${API}/manutencoes/${id}`, {
            method: 'DELETE'
        });

        const dados = await resposta.json();

        if (!resposta.ok) {
            throw new Error(dados.mensagem || 'Erro ao excluir manutenção.');
        }

        alert(dados.mensagem);

        await carregarManutencoes();

    } catch (erro) {

        alert(erro.message);
    }
}


// ========================================
// CRIAR RELACIONAMENTO - NEO4J
// ========================================

formRelacionamento.addEventListener('submit', async (evento) => {

    evento.preventDefault();

    const equipamentoId = Number(equipamentoRelacionamento.value);

    const manutencaoId = manutencaoRelacionamento.value;

    if (!equipamentoId || !manutencaoId) {

        alert('Selecione um equipamento e uma manutenção.');

        return;
    }

    try {

        // Consulta as manutenções no MongoDB
        const respostaManutencoes = await fetch(`${API}/manutencoes`);

        if (!respostaManutencoes.ok) {
            throw new Error('Erro ao consultar manutenções.');
        }

        const manutencoes = await respostaManutencoes.json();

        const manutencaoSelecionada = manutencoes.find(
            m => m._id === manutencaoId
        );

        if (!manutencaoSelecionada) {

            alert('Manutenção não encontrada.');

            return;
        }

        // Verifica se a manutenção pertence ao equipamento selecionado
        if (Number(manutencaoSelecionada.equipamentoId) !== equipamentoId) {

            alert(
                'A manutenção selecionada pertence a outro equipamento. ' +
                'Selecione o equipamento correspondente.'
            );

            return;
        }

        const resposta = await fetch(`${API}/relacionamentos`, {

            method: 'POST',

            headers: {
                'Content-Type': 'application/json'
            },

            body: JSON.stringify({
                equipamentoId: equipamentoId,
                manutencaoId: manutencaoId
            })

        });

        const dados = await resposta.json();

        if (!resposta.ok) {

            throw new Error(
                dados.mensagem || 'Erro ao criar relacionamento.'
            );
        }

        alert(dados.mensagem || 'Relacionamento criado com sucesso!');

        formRelacionamento.reset();

        await carregarRelacionamentos();

    } catch (erro) {

        console.error(erro);

        alert(erro.message);
    }
});


// ========================================
// LISTAR RELACIONAMENTOS - NEO4J
// ========================================

async function carregarRelacionamentos() {

    try {

        const resposta = await fetch(`${API}/relacionamentos`);

        if (!resposta.ok) {

            throw new Error('Erro ao consultar relacionamentos.');
        }

        const relacionamentos = await resposta.json();

        listaRelacionamentos.innerHTML = '';

        if (relacionamentos.length === 0) {

            listaRelacionamentos.textContent =
                'Nenhum relacionamento cadastrado no Neo4j.';

            return;
        }

        const tabela = document.createElement('table');

        tabela.innerHTML = `
            <thead>
                <tr>
                    <th>Equipamento</th>
                    <th>Número de série</th>
                    <th>Relacionamento</th>
                    <th>Manutenção</th>
                    <th>Técnico</th>
                    <th>Tipo</th>
                    <th>Status</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody></tbody>
        `;

        const tbody = tabela.querySelector('tbody');

        relacionamentos.forEach(r => {

            const linha = document.createElement('tr');

            const valores = [

                r.equipamento?.nome,

                r.equipamento?.numeroSerie,

                r.relacionamento,

                r.manutencao?.descricao,

                r.manutencao?.tecnico,

                r.manutencao?.tipo,

                r.manutencao?.status

            ];

            valores.forEach(valor => {

                const td = document.createElement('td');

                td.textContent = valor ?? '';

                linha.appendChild(td);

            });

            // ========================================
            // COLUNA DE ACOES
            // ========================================

            const acoes = document.createElement('td');

            // BOTAO EDITAR
            const botaoEditar = document.createElement('button');

            botaoEditar.textContent = 'Editar';

            botaoEditar.className = 'editar';

            botaoEditar.onclick = () => editarRelacionamento(
                r.equipamento?.postgresId,
                r.manutencao?.mongoId
            );

            // BOTAO EXCLUIR
            const botaoExcluir = document.createElement('button');

            botaoExcluir.textContent = 'Excluir';

            botaoExcluir.className = 'excluir';

            botaoExcluir.onclick = () => excluirRelacionamento(
                r.equipamento?.postgresId,
                r.manutencao?.mongoId
            );

            acoes.append(botaoEditar, botaoExcluir);

            linha.appendChild(acoes);

            tbody.appendChild(linha);

        });

        listaRelacionamentos.appendChild(tabela);

    } catch (erro) {

        console.error(erro);

        listaRelacionamentos.textContent =
            'Não foi possível carregar os relacionamentos do Neo4j.';
    }
}


// ========================================
// EDITAR RELACIONAMENTO - NEO4J
// ========================================


async function editarRelacionamento(equipamentoId, manutencaoId) {

    if (!equipamentoId || !manutencaoId) {
        alert('Não foi possível identificar o relacionamento.');
        return;
    }

    try {

        // Consulta os equipamentos
        const respostaEquipamentos = await fetch(`${API}/equipamentos`);
        const equipamentos = await respostaEquipamentos.json();

        // Consulta as manutenções
        const respostaManutencoes = await fetch(`${API}/manutencoes`);
        const manutencoes = await respostaManutencoes.json();

        if (!respostaEquipamentos.ok || !respostaManutencoes.ok) {
            throw new Error('Erro ao consultar os dados.');
        }

        // Localiza os dados atuais
        const equipamentoAtual = equipamentos.find(
            e => Number(e.id) === Number(equipamentoId)
        );

        const manutencaoAtual = manutencoes.find(
            m => m._id === manutencaoId
        );

        if (!equipamentoAtual || !manutencaoAtual) {
            throw new Error('Equipamento ou manutenção não encontrados.');
        }

        // Cria formulário para edição
        const formulario = document.createElement('div');

        formulario.innerHTML = `
            <h3>Editar relacionamento</h3>

            <label>Equipamento:</label>
            <select id="novoEquipamento">
                ${equipamentos.map(e => `
                    <option value="${e.id}"
                        ${Number(e.id) === Number(equipamentoId) ? 'selected' : ''}>
                        ${e.nome} - ${e.numero_serie}
                    </option>
                `).join('')}
            </select>

            <br><br>

            <label>Manutenção:</label>
            <select id="novaManutencao">
                ${manutencoes.map(m => `
                    <option value="${m._id}"
                        ${m._id === manutencaoId ? 'selected' : ''}>
                        ${m.descricao} - ${m.tecnico}
                    </option>
                `).join('')}
            </select>

            <br><br>

            <button id="salvarRelacionamento">Salvar</button>
            <button id="cancelarRelacionamento">Cancelar</button>
        `;

        listaRelacionamentos.prepend(formulario);

        // Botão cancelar
        document.getElementById('cancelarRelacionamento')
            .addEventListener('click', () => {
                formulario.remove();
            });

        // Botão salvar
        document.getElementById('salvarRelacionamento')
            .addEventListener('click', async () => {

                const novoEquipamentoId = Number(
                    document.getElementById('novoEquipamento').value
                );

                const novaManutencaoId =
                    document.getElementById('novaManutencao').value;

                // Verifica se a manutenção pertence ao equipamento
                const manutencaoSelecionada = manutencoes.find(
                    m => m._id === novaManutencaoId
                );

                if (
                    !manutencaoSelecionada ||
                    Number(manutencaoSelecionada.equipamentoId) !== novoEquipamentoId
                ) {
                    alert(
                        'A manutenção selecionada não pertence ao equipamento escolhido.'
                    );
                    return;
                }

                try {

                    const resposta = await fetch(
                        `${API}/relacionamentos/${equipamentoId}/${manutencaoId}`,
                        {
                            method: 'PUT',
                            headers: {
                                'Content-Type': 'application/json'
                            },
                            body: JSON.stringify({
                                equipamentoId: novoEquipamentoId,
                                manutencaoId: novaManutencaoId
                            })
                        }
                    );

                    const dados = await resposta.json();

                    if (!resposta.ok) {
                        throw new Error(
                            dados.mensagem || 'Erro ao atualizar relacionamento.'
                        );
                    }

                    alert(dados.mensagem);

                    formulario.remove();

                    await carregarRelacionamentos();

                } catch (erro) {
                    alert(erro.message);
                }
            });

    } catch (erro) {
        console.error(erro);
        alert(erro.message);
    }
}

// ========================================
// EXCLUIR RELACIONAMENTO - NEO4J
// ========================================

async function excluirRelacionamento(equipamentoId, manutencaoId) {

    if (!equipamentoId || !manutencaoId) {

        alert('Não foi possível identificar o equipamento ou a manutenção.');

        return;
    }

    if (!confirm('Deseja realmente excluir este relacionamento do Neo4j?')) {
        return;
    }

    try {

        const resposta = await fetch(
            `${API}/relacionamentos/${equipamentoId}/${manutencaoId}`,
            {
                method: 'DELETE'
            }
        );

        const dados = await resposta.json();

        if (!resposta.ok) {

            throw new Error(
                dados.mensagem || 'Erro ao excluir relacionamento.'
            );
        }

        alert(dados.mensagem || 'Relacionamento excluído com sucesso!');

        // Atualiza a tabela após a exclusão
        await carregarRelacionamentos();

    } catch (erro) {

        console.error(erro);

        alert(erro.message);
    }
}


// ========================================
// INICIAR A PAGINA
// ========================================

async function iniciarPagina() {

    await carregarEquipamentos();

    await carregarManutencoes();

    await carregarRelacionamentos();

}

iniciarPagina();
